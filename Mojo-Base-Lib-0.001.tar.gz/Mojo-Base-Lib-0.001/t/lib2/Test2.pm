package Test2;
use Mojo::Base::Lib -base;

1;